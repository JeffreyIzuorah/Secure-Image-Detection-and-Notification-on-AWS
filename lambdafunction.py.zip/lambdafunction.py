import json
import boto3
from s3functions import queue_url
from s3functions import topic_arn

rekognition_client = boto3.client('rekognition')
dynamodb_resource = boto3.resource('dynamodb')
sns_client = boto3.client('sns')
sqs_client = boto3.client('sqs')

response = sqs_client.get_queue_attributes(
    QueueUrl=queue_url,
    AttributeNames=['QueueArn']
)

queue_arn = response['Attributes']['QueueArn']

print(queue_arn)


lambda_client = boto3.client(
    'lambda')

response = lambda_client.create_event_source_mapping(
    EventSourceArn=queue_arn,
    FunctionName='lambda_handler',
    BatchSize=5,
    StartingPosition='LATEST'
)

print(response)

def lambda_handler(event, context):
    for record in event['Records']:
        filename = json.loads(record['body'])['filename']
        print(f"Processing file: {filename}")
        
        response = rekognition_client.detect_labels(
            Image={
                'S3Object': {
                    'Bucket': 'my-bucket-jeff',
                    'Name': filename
                }
            },
            MaxLabels=5,
            MinConfidence=80
        )
        
        table = dynamodb_resource.Table('my-table')
        item = {'filename': filename}
        for label in response['Labels']:
            item[label['Name']] = label['Confidence']
        table.put_item(Item=item)
        
        if 'Pedestrian' in item and item['Pedestrian'] >= 80:
            sns_client.publish(
                TopicArn=topic_arn,
                Message=f"Pedestrian detected in {filename}"
            )
